"""RAG application services."""
